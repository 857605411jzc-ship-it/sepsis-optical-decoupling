# Higher relative rebound, lower peak perfusion in sepsis

**Online Resource 2. Reproducible analyses and Figure 1.** Zongchen Jiang, Xin Zhao and Wensheng Qi.

This repository compares the five-minute basal perfusion index (PI) with the information obtained by adding a three-minute upper-arm cuff occlusion and five minutes of recovery sampling. It uses the deidentified cohort from four Brazilian intensive care units reported by de Miranda et al., *PLOS ONE* (2023). The unit of resampling and validation is the participant.

## Reproduce

Use 64-bit Python 3.12. From the extracted directory run

```bash
python -m pip install -r requirements.txt
python run_all.py
```

The first run downloads the publisher's [S1 Table](https://doi.org/10.1371/journal.pone.0288249.s001). For offline analysis, save the original SPSS file at `data/cohort.sav`. The loader verifies SHA-256 `ae1f810153b1d75b2d65a4c5f3f411fd0459d377f14f75800409a5a559192cec`. The source article describes recruitment, oversight and the measurement protocol. [Source article](https://doi.org/10.1371/journal.pone.0288249).

For temporal validation of resting PI, the same command retrieves the earlier Brazilian cohort enrolled between February and December 2019. For offline use, save its [S1 File](https://doi.org/10.1371/journal.pone.0239770.s004) at `data/resting_2019.sav`. The expected SHA-256 is `adbecca372e88386624c9bee844c2b1f07be017e9c58660ff99d14fd77168a59`. The resting-PI model for in-hospital death within 28 days of sepsis diagnosis, fitted to the 226 participants, is applied to 141 earlier patients without refitting. This cohort contains no cuff-release measurements. [Cohort article](https://doi.org/10.1371/journal.pone.0239770).

The command creates `results/`, checks the recalculated statistics against the aggregate tables in `expected/`, and renders `Fig1_ICM.pdf` (vector) and `Fig1_ICM.png` (600 dpi) in `results/figures/`. The publication figure uses Arial. On systems without Arial the renderer uses an available sans-serif alternative; exact typography requires the same fonts. The source SPSS file and derived participant points are created locally and are excluded from this archive.

## Measures and comparisons

The basal measurement B is the mean perfusion index before cuff inflation. The post-release peak P is the maximum of ten PI values recorded at 30-second intervals. The conventional ratio is P/B. We define reactivity E as log₂ P minus the expected log₂ peak at the same log₂ B, with a common day-1 reference across visits. For prediction, the reference, covariate preprocessing and outcome model are fitted separately within each training fold.

Figure 1a uses all 226 recorded day-1 rebound categories, and the dashed line is the nominal sampled threshold P = 1.62B. Four participants differ between the recorded labels and the threshold reapplied to the ten recovery readings. The 220 participants in the published multivariable model have complete day-1 age, SOFA, heart rate, lactate, baseline PI and outcome data. Absolute rise is the participant’s sampled peak minus that same participant’s basal PI. The count of peaks below the other group’s resting median uses strict inequality at full numerical precision.

The next-day CRT comparison includes patients with day-1 MAP ≥65 mmHg and observed day-2 CRT. We evaluate CRT >3 s and the source definition of delayed CRT, ≥3 s. The distinct mortality comparison includes all 226 patients and uses in-hospital death by day 28. In the day-2 landmark analyses, the 208 participants with paired optics and a recorded time to outcome greater than two days contributed 73 deaths. Cox models use Efron ties and end hospital follow-up at live discharge, death or day 28.

## Results guide

| Question | Regenerated files under `results/` |
| --- | --- |
| Cohort flow, available records and endpoint definitions | `risk_sets.csv`, `comparisons/denominators.csv` |
| Day-specific scaling, bootstrap slope intervals and between-day interaction | `sensitivity/allometry.csv`, `sensitivity/allometry_bootstrap.csv`, `sensitivity/day_interaction.csv` |
| Published Table 2, recorded versus reconstructed high rebound, and baseline adjustment | `source_table2_results.csv`, `source_table2_encoding.csv`, `source_peak_bridge.csv` |
| Group medians of basal PI, sampled peak and within-person absolute rise, plus high-rebound peaks below the low group’s resting median, in 226 and 220 participants | `rebound_group_measures.csv`, `rebound_group_overlap.csv` |
| Paired bootstrap comparison of the source and expanded mortality models | `sensitivity/source_OR_paired_refit.csv` |
| Basal, challenge and manual CRT performance on matched folds; 5,000 resamples with held-out predictions fixed | `comparisons/metrics.csv`, `comparisons/paired_contrasts.csv` |
| Two thousand patient-level bootstrap samples with training refits, including both CRT thresholds and mortality | `sensitivity/refitted_validation.csv` |
| Quadratic basal-only versus full quadratic joint models with a basal-by-peak interaction | `sensitivity/peak_interaction.csv` |
| Two-day coordinates, clinical anchors, adjusted logistic and cause-specific Cox models | `model_checks.csv`, `landmark_correlations.csv` |
| Original two-stage bootstrap for day-1 and trajectory mortality odds ratios | `sensitivity/mortality_BE_refit_bootstrap.csv`, `sensitivity/mortality_trajectory_refit_bootstrap.csv` |
| Restriction to MAP ≥65 mmHg and the alternative endpoint incorporating death by day 2 | `sensitivity/crt_population_metrics.csv`, `sensitivity/crt_population_contrasts.csv` |
| Day-2 clinical benchmarks and paired changes in prediction | `metrics.csv`, `contrasts.csv`, `basal_metrics.csv`, `basal_contrasts.csv` |
| Clinical follow-up across CRT and perfusion subgroups | `state_counts.csv`, `allometry_subgroups.csv`, `crt_subgroups.csv`, `landmark_missing_donor_sensitivity.csv` |
| Mortality discrimination and calibration-in-the-large (via mean predicted and observed risk) in the earlier cohort with resting PI | `external/basal_mortality.csv` |
| Panels b and c: effect estimates, confidence bounds and discrimination | `Fig1_data.csv` |

The master seed is 2026111234. Validation uses 20 repeats of stratified fivefold splits. All compared models share the same patients and splits within an endpoint. AUROC and Brier are computed on the pooled held-out predictions in each repeat and then averaged over repeats. Positive AUROC gain and Brier gain both favour the augmented model. For refitted uncertainty, each bootstrap resample preserves each patient's original fold assignment within each repeat, so duplicate observations stay together. Training likelihoods and held-out scores use the participant's multiplicity. Percentile intervals include model refitting variation conditional on the original split assignments. The reference and mortality regression are refitted in each of the 1,500 resamples used for the separate longitudinal odds-ratio interval.

"""Collect Figure 1 values from recalculated aggregate estimates."""
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"


def get_one(table, **conditions):
    mask = pd.Series(True, index=table.index)
    for variable, value in conditions.items():
        mask &= table[variable].eq(value)
    rows = table.loc[mask]
    if len(rows) != 1:
        raise ValueError(f"Expected one row for {conditions}, found {len(rows)}.")
    return rows.iloc[0]


def figures_data():
    mortality = pd.read_csv(RESULTS / "source_peak_bridge.csv")
    source = pd.read_csv(RESULTS / "source_table2_results.csv")
    optical = pd.read_csv(RESULTS / "comparisons" / "metrics.csv")
    refit = pd.read_csv(RESULTS / "sensitivity" / "refitted_validation.csv")
    rows = []

    def add(panel, endpoint, model, statistic, row, count, point, lo=None, hi=None):
        rows.append(dict(panel=panel, outcome=endpoint, model=model, statistic=statistic,
                         n=int(row["n"]), events=int(row[count]), estimate=row[point],
                         lower=row[lo] if lo else None, upper=row[hi] if hi else None))

    for method, model in [("without_b", "r1"), ("with_b", "x1+r1")]:
        row = get_one(mortality, model=model, term="r1")
        add("b", "death", "ratio", method, row, "deaths", "estimate", "lo", "hi")

    for method, model in [("without_b", "source_covariates"), ("with_b", "add_log2_basal_PI")]:
        row = get_one(source, encoding="high_PIMR_recorded", model=model, term="high_PIMR_recorded")
        add("b", "death", "clinical_category", method, row, "deaths", "OR", "lower95", "upper95")

    for key, task in [("crt", "day2_CRT_gt3"), ("death", "day28_in_hospital_death")]:
        predictors = ["R", "B", "B_E", "CRT"] if key == "crt" else ["R", "B", "B_E"]
        for predictor in predictors:
            row = get_one(optical, task=task, model=predictor)
            add("c", key, predictor, "auc", row, "events", "AUROC")
        row = get_one(refit, endpoint=task, metric="AUROC_gain")
        add("c", key, "B_E-B", "delta_auc", row, "events", "estimate", "lower", "upper")
    return pd.DataFrame(rows)


if __name__ == "__main__":
    figures_data().to_csv(RESULTS / "Fig1_data.csv", index=False)

"""Plot the cohort measurements and paired comparisons for Figure 1."""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import NullLocator, FixedLocator, FuncFormatter
from matplotlib import font_manager
import numpy as np
import pandas as pd


WIDTH, HEIGHT = 174, 168
INK, MUTED = "#18303f", "#425765"
HIGH, LOW = "#a14830", "#275d7d"
BASAL, JOINT, RATIO = "#265b79", "#103c52", "#667782"
AXIS, GUIDE, LIGHT = "#70828b", "#b4bfc2", "#e1e6e7"


def label(fig, x, y, value, **kwargs):
    style = dict(ha="left", va="center", fontsize=8.5, color=INK)
    style.update(kwargs)
    return fig.text(x / WIDTH, 1 - y / HEIGHT, value, **style)


def axes(fig, x0, x1, y0, y1):
    return fig.add_axes([x0 / WIDTH, 1 - y1 / HEIGHT,
                         (x1 - x0) / WIDTH, (y1 - y0) / HEIGHT])


def rule(fig, x0, x1, y0, y1, color, lw=0.55, ls="-"):
    line = plt.Line2D([x0 / WIDTH, x1 / WIDTH], [1 - y0 / HEIGHT, 1 - y1 / HEIGHT],
                      transform=fig.transFigure, c=color, lw=lw, ls=ls)
    fig.add_artist(line)


def glyph(fig, x, y, marker, edge, fill, size=5):
    line = plt.Line2D([x / WIDTH], [1 - y / HEIGHT], transform=fig.transFigure,
                      ls="none", marker=marker, ms=size, mfc=fill, mec=edge, mew=0.9)
    fig.add_artist(line)


def configure_axes(ax, y_visible=False):
    for spine in ("right", "top"):
        ax.spines[spine].set_visible(False)
    ax.spines["left"].set_visible(y_visible)
    ax.spines["bottom"].set_color(AXIS)
    ax.spines["left"].set_color(AXIS)
    ax.tick_params(colors=MUTED, length=2.6, width=0.55, pad=2.3, labelsize=8)
    if not y_visible:
        ax.set_yticks([])


def plot_patients(fig, patients):
    label(fig, 1, 4.3, "a", weight="bold", fontsize=12)
    label(fig, 7, 4.3, "Day 1 perfusion index", weight="bold", fontsize=10)
    groups = patients.groupby("source_high")
    stats = groups[["B", "P"]].median()
    counts = groups.size()
    for group, color, marker, x, text in [(0, LOW, "o", 7.8, "Low rebound"),
                                           (1, HIGH, "D", 47, "High rebound")]:
        glyph(fig, x, 12.2, marker, color, color, 4)
        label(fig, x + 2.4, 12.2, f"{text} (n = {counts[group]})", fontsize=8)
    ax = axes(fig, 14.7, 89.5, 20, 76.8)
    ax.set_xscale("log", base=2)
    ax.set_yscale("log", base=2)
    ax.set_xlim(0.054, 18)
    ax.set_ylim(0.125, 25)
    configure_axes(ax, True)
    xticks = [0.125, 0.25, 0.5, 1, 2, 4, 8, 16]
    yticks = [0.25, 0.5, 1, 2, 4, 8, 16]
    for axis, ticks in [(ax.xaxis, xticks), (ax.yaxis, yticks)]:
        axis.set_major_locator(FixedLocator(ticks))
        axis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:g}"))
        axis.set_minor_locator(NullLocator())
    ax.set_axisbelow(True)
    ax.grid(axis="both", color=LIGHT, lw=0.45)
    for group, color, shape in [(0, LOW, "o"), (1, HIGH, "D")]:
        d = groups.get_group(group)
        ax.scatter(d.B, d.P, s=12 if group == 0 else 13, c=color, marker=shape,
                   linewidths=0.29, edgecolors="white", zorder=3)
    basal = np.log2(patients.B.to_numpy())
    beta, alpha = np.polyfit(basal, np.log2(patients.P.to_numpy()), 1)
    grid = np.geomspace(patients.B.min(), patients.B.max(), 180)
    ax.plot(grid, 2**alpha * grid**beta, c=INK, lw=1.10, zorder=4)
    ax.plot(grid, 1.62 * grid, c=MUTED, ls=(0, (4, 2.4)), lw=0.98, zorder=4)
    ax.set_xlabel("Resting PI", fontsize=9, labelpad=3, color=INK)
    ax.set_ylabel("Sampled peak PI", fontsize=9, labelpad=2.5, color=INK)
    rule(fig, 10, 17, 88.6, 88.6, INK, 1.10)
    label(fig, 18.3, 88.6, f"Fitted slope β = {beta:.2f}", fontsize=8)
    rule(fig, 49.3, 56.3, 88.6, 88.6, MUTED, 0.98, (0, (4, 2.4)))
    label(fig, 57.8, 88.6, "62% rebound (P = 1.62B)", fontsize=8)
    label(fig, 98.5, 12.2, "Group medians (PI)", weight="bold", fontsize=9.5)
    glyph(fig, 100, 20, "o", MUTED, "white", 5.1)
    label(fig, 102.2, 20, "Resting", fontsize=8)
    glyph(fig, 120, 20, "o", MUTED, MUTED, 5.1)
    label(fig, 122.2, 20, "Sampled peak", fontsize=8)
    rail = axes(fig, 100, 169, 24.5, 72)
    rail.set_xlim(0, 5.2)
    rail.set_ylim(-0.45, 1.85)
    configure_axes(rail)
    rail.set_xticks(range(6))
    rail.set_xlabel("Perfusion index", fontsize=9, labelpad=2.8, color=INK)
    resting_low = stats.at[0, "B"]
    rail.vlines(resting_low, -0.45, 1.17, color=GUIDE, ls=(0, (2.4, 2)), lw=0.9)
    for group, row_y, color, group_label in [(0, 1.17, LOW, "Low rebound"),
                                               (1, 0.05, HIGH, "High rebound")]:
        resting, peak = stats.loc[group, ["B", "P"]]
        rail.text(0.04, row_y + 0.37, group_label, color=color, size=9, weight="bold")
        rail.plot([resting, peak], [row_y, row_y], c=color, lw=1.7)
        rail.plot(resting, row_y, "o", color=color, mfc="white", ms=6.3, mew=1.25)
        rail.plot(peak, row_y, "o", color=color, mfc=color, ms=6.3, mew=1.1)
        rail.annotate(f"{resting:.2f}", (resting, row_y), xytext=(-1.3, 7.6),
                      textcoords="offset points", ha="right", fontsize=9, color=color)
        rail.annotate(f"{peak:.2f}", (peak, row_y), xytext=(1.3, 7.6),
                      textcoords="offset points", ha="left", fontsize=9, color=color, weight="bold")
    n_below = groups.get_group(1).P.lt(resting_low).sum()
    label(fig, 99, 85.2, f"{n_below}/{counts[1]} high-rebound peaks fell below", fontsize=8.5)
    label(fig, 99, 89.6, f"the low group's resting median ({resting_low:.2f}).", fontsize=8.5)


def plot_odds(fig, data):
    label(fig, 1, 98.7, "b", weight="bold", fontsize=12)
    label(fig, 7, 98.7, "Odds of in-hospital death", weight="bold", fontsize=9.7)
    for x, stat, marker, fill in [(5, "Without resting PI", "o", "white"), (38.5, "With resting PI", "s", JOINT)]:
        glyph(fig, x, 105.4, marker, JOINT, fill)
        label(fig, x+2.4, 105.4, stat, fontsize=8)
    forest = axes(fig, 5, 34.5, 112.6, 152.6)
    forest.set_xscale("log", base=2)
    forest.set_xlim(.55, 4.3)
    forest.set_ylim(152.6, 112.6)
    configure_axes(forest)
    for first, last in [(114.3, 128.6), (136.2, 152.6)]:
        forest.vlines(1, first, last, color=GUIDE, lw=0.7, ls=(0, (2.4, 2)))
    forest.set_xticks([1, 2, 4], ["1", "2", "4"])
    forest.xaxis.set_minor_locator(NullLocator())
    for key, label_y, row_1, row_2, title in [
        ("ratio", 111.6, 118.3, 124.5, "Ratio per doubling"),
        ("clinical_category", 133.2, 140.0, 146.3, "High vs low, adjusted")]:
        initial = data.loc["death", key, "without_b"]
        label(fig, 3.8, label_y, f"{title} (n = {int(initial.n)})", fontsize=8.15, weight="bold")
        for which, y, marker, fill in [("without_b", row_1, "o", "white"),
                                        ("with_b", row_2, "s", JOINT)]:
            row = data.loc["death", key, which]
            forest.hlines(y, row.lower, row.upper, color=JOINT, lw=.9)
            forest.vlines([row.lower, row.upper], y-.7, y+.7, color=JOINT, lw=.65)
            forest.plot(row.estimate, y, marker=marker, c=JOINT, mfc=fill, ms=4.6, mew=.95)
            label(fig, 36.5, y, f"{row.estimate:.2f} ({row.lower:.2f}–{row.upper:.2f})",
                  fontsize=8.1, color=JOINT)
    label(fig, 4.0, 162.1, "Odds ratio (95% CI)", fontsize=8.5)


def plot_accuracy(fig, data):
    label(fig, 69.5, 98.7, "c", weight="bold", fontsize=12)
    label(fig, 75.5, 98.7, "Day 1 discrimination", weight="bold", fontsize=9.7)
    for y, name in [(118.3,"Rebound ratio"),(125,"Resting PI, 5 min"),
                    (131.7,"Full test, 13 min"),(138.4,"Bedside CRT")]:
        label(fig, 71.0, y, name, fontsize=8.2, color=MUTED if name=="Bedside CRT" else INK)
    for key, lo, hi, title in [
        ("crt", 102.3, 131.8, "Next-day CRT >3 s"),
        ("death", 140.0, 169.5, "28-day in-hospital death")]:
        center = (lo + hi) / 2
        label(fig, center, 106.7, title, ha="center", weight="bold", fontsize=8.05)
        label(fig, center, 111.0, f"n = {int(data.loc[key,'B','auc'].n)}", ha="center", fontsize=8, color=MUTED)
        ax = axes(fig, lo, hi, 114, 143.5)
        ax.set_xlim(.5, .83)
        ax.set_ylim(143.5, 114)
        configure_axes(ax)
        ax.set_xticks([.5,.65,.8], ["0.50","0.65","0.80"])
        ax.grid(axis="x", color=LIGHT, lw=.5)
        for model, y, color, symbol, fill in [
            ("R",118.3,RATIO,"o","white"), ("B",125,BASAL,"s",BASAL),
            ("B_E",131.7,JOINT,"D",JOINT), ("CRT",138.4,RATIO,"^","white")]:
            if (key, model, "auc") not in data.index:
                continue
            value = data.loc[key,model,"auc"].estimate
            ax.plot(value, y, symbol, c=color, mfc=fill, ms=4.3, mew=0.95)
            ax.annotate(f"{value:.3f}", (value,y), xytext=(0,-4), ha="center", va="top",
                        textcoords="offset points", fontsize=7.8, color=color)
        label(fig, center, 151.0, "AUROC", ha="center", fontsize=8, color=MUTED)
        d = data.loc[key, "B_E-B", "delta_auc"]
        def signed(value):
            return f"{value:+.3f}".replace("-", "−")
        label(fig, center, 158.1, signed(d.estimate), fontsize=9, weight="bold", ha="center")
        label(fig, center, 163.3, f"({signed(d.lower)}, {signed(d.upper)})", fontsize=8.0, ha="center")
    label(fig, 71, 158.1, "Full test – resting PI", fontsize=8, weight="bold")
    label(fig, 71, 163.3, "ΔAUROC (95% CI)", fontsize=8.0, color=MUTED)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--patients", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    patients = pd.read_csv(args.patients)
    data = pd.read_csv(args.data).set_index(["outcome","model","statistic"]).sort_index()
    for path in font_manager.findSystemFonts(fontext="ttf"):
        if Path(path).stem.lower().startswith(("arial", "helvetica")):
            font_manager.fontManager.addfont(path)
    matplotlib.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"],
        "font.size": 8.5, "pdf.fonttype": 42, "ps.fonttype": 42, "axes.linewidth": .6,
        "pdf.compression": 6, "figure.facecolor": "white", "axes.labelcolor": INK,
    })
    fig = plt.figure(figsize=(WIDTH/25.4, HEIGHT/25.4))
    plot_patients(fig, patients)
    rule(fig, 0.8, 172.8, 94.5, 94.5, GUIDE)
    plot_odds(fig, data)
    plot_accuracy(fig, data)
    args.out.mkdir(exist_ok=True, parents=True)
    for kind in ("pdf", "png"):
        fig.savefig(args.out / f"Fig1_ICM.{kind}", dpi=600, facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    main()

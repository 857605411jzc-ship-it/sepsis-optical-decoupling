"""Reproduce all clinical analyses, check the aggregate outputs and draw Figure 1."""
from pathlib import Path
import os
import subprocess
import sys

import pandas as pd


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"


def verify_outputs():
    for standard in sorted((ROOT / "expected").rglob("*.csv")):
        relative = standard.relative_to(ROOT / "expected")
        calculated = pd.read_csv(RESULTS / relative)
        expected = pd.read_csv(standard)
        pd.testing.assert_frame_equal(calculated, expected, check_exact=False, rtol=1e-5,
                                      atol=1e-7, obj=str(relative))
    print("All reference estimates reproduced.", flush=True)


def main():
    env = os.environ.copy()
    for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
        env[key] = "1"
    env["PYTHONUNBUFFERED"] = "1"
    sensitivity = RESULTS / "sensitivity"
    sensitivity.mkdir(exist_ok=True, parents=True)

    def run(script, *args):
        print(f"Running {script}", flush=True)
        subprocess.run([sys.executable, ROOT / script, *args], cwd=ROOT, env=env, check=True)

    for script in ("rebound_groups", "reference_checks", "geometry", "landmark", "basal_comparison", "source_table2", "crt_comparison", "external_basal"):
        run(f"analysis/{script}.py")
    for script in ("refit_validation", "source_group_overlap", "peak_interaction", "crt_population_checks"):
        run(f"analysis/{script}.py", "--base", ROOT, "--out", sensitivity)
    run("figures/assemble_figure.py")
    verify_outputs()
    run("figures/render_Fig1.py", "--data", RESULTS / "Fig1_data.csv",
        "--patients", RESULTS / "figure_patients.csv", "--out", RESULTS / "figures")


if __name__ == "__main__":
    main()

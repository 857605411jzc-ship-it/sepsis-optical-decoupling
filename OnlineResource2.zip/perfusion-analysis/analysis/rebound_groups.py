"""Describe absolute PI in the study's recorded day-1 rebound groups."""
from pathlib import Path

import numpy as np
import pandas as pd
import pyreadstat

from published_load import load


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"


def group_measures(sample, population):
    low = sample.loc[sample.source_high.eq(0)]
    high = sample.loc[sample.source_high.eq(1)]
    low_rest = low.B1.median()
    rows = []
    for group, patients in (("low", low), ("high", high)):
        for label, values in (("basal_PI", patients.B1), ("sampled_peak_PI", patients.P1),
                              ("absolute_rise", patients.P1 - patients.B1), ("ratio", patients.R1)):
            q1, median, q3 = values.quantile([0.25, 0.5, 0.75])
            rows.append(dict(population=population, group=group, n=len(patients),
                             measure=label, q1=q1, median=median, q3=q3))
    beta, intercept = np.polyfit(sample.x1, sample.y1, 1)
    comparison = dict(population=population, n=len(sample), high_n=len(high), low_n=len(low),
                      low_rest_median=low_rest, high_peak_below_low_rest=int(high.P1.lt(low_rest).sum()),
                      high_peak_equal_low_rest=int(high.P1.eq(low_rest).sum()),
                      day1_log2_intercept=intercept, day1_log2_slope=beta)
    return rows, comparison


def main():
    path = ROOT / "data" / "cohort.sav"
    data = load(path)
    source, _ = pyreadstat.read_sav(path, usecols=["∆PI_PEAK_D1_A", "Heart_Rate_Day1"])
    data["source_high"] = source["∆PI_PEAK_D1_A"].astype(int)
    data["heart_rate"] = source["Heart_Rate_Day1"]
    complete = data.dropna(subset=["age", "sofa_d1", "heart_rate", "lactate1", "death"])
    rows, overlaps = [], []
    for name, sample in (("full_cohort", data), ("source_model_complete", complete)):
        measures, comparison = group_measures(sample, name)
        rows.extend(measures)
        overlaps.append(comparison)
    RESULTS.mkdir(exist_ok=True)
    pd.DataFrame(rows).to_csv(RESULTS / "rebound_group_measures.csv", index=False)
    pd.DataFrame(overlaps).to_csv(RESULTS / "rebound_group_overlap.csv", index=False)
    points = data[["B1", "P1", "source_high"]].rename(columns={"B1": "B", "P1": "P"})
    points.to_csv(RESULTS / "figure_patients.csv", index=False)


if __name__ == "__main__":
    main()

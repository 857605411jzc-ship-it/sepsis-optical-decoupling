"""Assess the MAP restriction and an endpoint incorporating early hospital death."""
import argparse
from pathlib import Path
import sys

import pandas as pd


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent / "results")
    args = parser.parse_args()
    sys.path.insert(0, str(args.base.resolve() / "analysis"))
    from published_load import load
    from basal_comparison import validate
    data = load(args.base / "data" / "cohort.sav")
    early_death = data.death.eq(1) & data.time_to_outcome.le(2)
    observed = data.crt_sec_d2.notna()
    prolonged = data.crt_sec_d2.gt(3)
    tasks = [
        ("all_MAP_observed_CRT", observed, prolonged),
        ("MAP_ge65_early_death_or_prolonged_CRT",
         data.map_d1.ge(65) & (early_death | observed), early_death | prolonged),
    ]
    models = {"B": ["x1"], "B_E": ["x1", "E1"], "R": ["r1"]}
    metrics, contrasts = [], []
    for name, eligible, event in tasks:
        frame = data.loc[eligible].copy()
        frame["target"] = event.loc[eligible].astype(int)
        p, c = validate(frame, "target", models, [("B", "B_E")], name)
        c.insert(1, "events", int(frame.target.sum()))
        c.insert(1, "n", len(frame))
        metrics.append(p)
        contrasts.append(c)
    args.out.mkdir(parents=True, exist_ok=True)
    pd.concat(metrics, ignore_index=True).to_csv(args.out / "crt_population_metrics.csv", index=False)
    pd.concat(contrasts, ignore_index=True).to_csv(args.out / "crt_population_contrasts.csv", index=False)


if __name__ == "__main__":
    main()

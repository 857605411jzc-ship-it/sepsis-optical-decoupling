from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from scipy.stats import norm, t, fisher_exact
from scipy.stats import false_discovery_control
from published_load import load

package = Path(__file__).resolve().parents[1]
out = package/'results'
source = package/'data'/'cohort.sav'
d = load(source)
a,b=np.linalg.lstsq(np.c_[np.ones(len(d)),d.x1],d.y1,rcond=None)[0]
d['E1']=d.y1-a-b*d.x1
d['E2']=d.y2-a-b*d.x2
d['dE']=d.E2-d.E1
d['x1E1']=d.x1*d.E1
lm=d[(d.time_to_outcome>2)&d.B2.notna()].copy()
results=[]
def fit(frame,outcome,terms,label,kind='logit'):
    q=frame.dropna(subset=[outcome]+terms)
    M=q[terms].to_numpy()
    y=q[outcome].to_numpy()
    X=np.column_stack([np.ones(len(y)),M])
    if kind=='logit':
        beta=np.zeros(X.shape[1])
        for i in range(50):
            prob=expit(X@beta)
            weights=prob*(1-prob)
            cov=np.linalg.inv(X.T@(X*weights[:,None]))
            step=cov@(X.T@(y-prob)); beta+=step
            if abs(step).max()<1e-11:break
        se=np.diag(cov)**.5; pvals=2*norm.sf(abs(beta/se))
        ci=1.96*se
        fx=np.exp
    elif kind=='ols':
        beta=np.linalg.lstsq(X,y,rcond=None)[0];bread=np.linalg.inv(X.T@X);u=y-X@beta
        h=(X*(X@bread)).sum(1); scores=X*(u/(1-h))[:,None]
        cov=bread@scores.T@scores@bread
        se=np.diag(cov)**.5
        pvals=2*t.sf(abs(beta/se),len(y)-X.shape[1])
        ci=t.ppf(.975,len(y)-X.shape[1])*se;fx=lambda v:v
    for j,term in enumerate(['intercept']+terms):
        results.append(dict(model=label,outcome=outcome,term=term,n=len(q),deaths=q.death.sum(),estimate=fx(beta[j]),lo=fx(beta[j]-ci[j]),hi=fx(beta[j]+ci[j]),p=pvals[j]))
    return X@beta
tc=['age','sofa_d1','x1','E1','dx','dE']
prA=fit(lm,'death',tc,'paired_change')
prB=fit(lm,'death',['age','sofa_d1','x1','E1','x2','E2'],'paired_endpoints')
assert np.allclose(prA,prB,rtol=1e-12,atol=1e-12)
for fr, lab in [(d,'all_day1'),(lm,'lm_day1'),(d[d.shock==1],'shock_day1')]:
    fit(fr,'death',['age','sofa_d1','x1','E1'],lab)
fit(d,'death',['age','sofa_d1','x1','E1','x1E1'],'interaction')
fit(lm,'death',['age','sofa_d1','x2','E2'],'lm_day2_snapshot')
for y,base,lab in [('crt_sec_d2','crt_sec_d1','crt_day2'),('loglac2','loglac1','lac_day2')]:
    fit(d,y,tc+[base],lab,kind='ols')
for rfeatures in [['r1'],['x1','r1']]:
    fit(d,'death',rfeatures,'+'.join(rfeatures))
# Efron partial likelihood for recorded days. Live exits are removed from the death risk set.
def cox(frame,terms):
    T=frame.time_to_outcome.values-2; event=frame.death.values.astype(bool)
    X=frame[terms].values;std=X.std(0);X=(X-X.mean(0))/std
    steps=[(X[T>=u],X[(T==u)&event]) for u in np.unique(T[event])]
    def partial(b):
        ll=0.; score=np.zeros(X.shape[1]); inf=np.zeros((X.shape[1],X.shape[1]))
        for risk,dead in steps:
            eta=risk@b; center=max(eta); w=np.exp(eta-center); wd=np.exp(dead@b-center)
            m=len(dead);ll+=(dead@b).sum();score+=dead.sum(0)
            wr=w@risk;ed=wd@dead;sr=risk.T@(w[:,None]*risk);sd=dead.T@(wd[:,None]*dead)
            for frac in np.arange(m)/m:
                den=w.sum()-frac*wd.sum(); z=(wr-frac*ed)/den
                ll-=np.log(den)+center;score-=z
                inf+=(sr-frac*sd)/den-np.outer(z,z)
        return ll,score,inf
    b=np.zeros(X.shape[1])
    for i in range(30):
        ll,score,inf=partial(b); step=np.linalg.solve(inf,score);b+=step
        if abs(step).max()<1e-10:break
    _,score,inf=partial(b);assert abs(score).max()<1e-7
    se=np.diag(np.linalg.inv(inf))**.5/std;b=b/std
    for j,n in enumerate(terms):
        results.append(dict(model='landmark_cause_specific_cox_efron',outcome='in_hospital_death_by_28',term=n,n=len(frame),deaths=event.sum(),estimate=np.exp(b[j]),lo=np.exp(b[j]-1.96*se[j]),hi=np.exp(b[j]+1.96*se[j]),p=2*norm.sf(abs(b[j]/se[j]))))
cox(lm,tc)
tab=pd.DataFrame(results)
f=tab[tab.model.isin(['paired_change','crt_day2','lac_day2'])&tab.term.isin(['dE','dx'])]
tab.loc[f.index,'q6']=false_discovery_control(f.p.to_numpy())
tab.to_csv(out/'model_checks.csv',index=False)
print(tab[tab.term.isin(['r1','E1','E2','dE','dx','x1E1'])].round(5).to_string(index=False))
print('Maximum pair representation difference in predicted probs',max(abs(expit(prA)-expit(prB))))
print('baseline delta correlations',lm[['E1','E2','dE','dx']].corr().round(3).to_string())
groups=[]
for cut in [d.B1.median(),1.4]:
    low=d[d.B1<cut]
    ct=pd.crosstab(low.E1>=0,low.death)
    print('low',cut,ct, fisher_exact(ct.values))
    for (lb,he),g in d.groupby([d.B1<cut,d.E1>=0]):
        groups.append(dict(cut=cut,low_baseline=lb,above=he,n=len(g),deaths=int(g.death.sum())))
pd.DataFrame(groups).to_csv(out/'state_counts.csv',index=False)
print('minima followup', d.groupby('death').time_to_outcome.agg(['min','max']).to_string())

# Slope heterogeneity by clinical exposures available in the public source.
subgroups = []
def subgroup_fit(frame, terms, label):
    before = len(results)
    fit(frame, 'y1', terms, label, kind='ols')
    subgroups.append(results[-1])
    del results[before:]

for variable in ['vaso_d1', 'shock']:
    frame = d.dropna(subset=[variable]).copy()
    frame['interaction'] = frame.x1 * frame[variable]
    subgroup_fit(frame, ['x1', variable, 'interaction'], f'{variable}_interaction')
    for level, subset in frame.groupby(variable):
        subgroup_fit(subset, ['x1'], f'{variable}_{level:g}')
frame = d[(d.vaso_d1 == 1) & (d.norepi1 > 0)].copy()
frame['dose'] = np.log2(frame.norepi1)
frame['dose'] -= frame.dose.mean()
frame['interaction'] = frame.dose * frame.x1
subgroup_fit(frame, ['x1', 'dose', 'interaction'], 'treated_log2_NE_interaction')
pd.DataFrame(subgroups).to_csv(out/'allometry_subgroups.csv', index=False)

# The one missing follow-up record among patients still at risk is assigned
# each observed day-2 coordinate pair, retaining the recipient's baseline.
eligible = d[d.time_to_outcome.gt(2)].copy()
missing = eligible[eligible.B2.isna()].copy()
assert len(missing) == 1
donor_rows = []
for _, donor in lm.iterrows():
    recipient = missing.copy()
    recipient['dx'] = donor.x2 - recipient.x1
    recipient['dE'] = donor.E2 - recipient.E1
    before = len(results)
    fit(pd.concat([lm, recipient]), 'death', tc, 'observed_day2_pair')
    donor_rows.append(results[-1])
    del results[before:]
effects = pd.DataFrame(donor_rows)
effects[['estimate', 'lo', 'hi']].agg(['min','max']).to_csv(out/'landmark_missing_donor_sensitivity.csv')

from pyreadstat import read_sav

import pandas as pd
import numpy as np
raw,_=read_sav(source)
rows=[]
def one(frame,terms,label):
    start=len(results)
    fit(frame,'death',terms,label)
    rows.extend(results[start:])
    del results[start:]
g=d.copy()
g['published_high_PIMR']=raw['∆PI_PEAK_D1_A']
g['recorded_r1']=np.log2(1+raw['∆PI_PEAK_D1']/100.)
for var in ['published_high_PIMR','recorded_r1','r1']:
    for terms in [[var],['x1',var]]:
        one(g,terms,'+'.join(terms))
alt=lm.copy()
alt['source_peak2']=raw.loc[alt.index,'∆PI_PEAK_Day_2']
alt['dE']=np.log2(alt.source_peak2.where(alt.source_peak2>0))-a-b*alt.x2-alt.E1
one(alt,tc,'recorded_day2_absolute_peak')
# The codebook label flags a percent threshold on day 1; check the archived raw field before comparing.
print('Day1 cutoff assignment discrepancies',sum((g.R1>1.62).astype(float)!=g.published_high_PIMR))
print('Day2 reported absolute peak n different by more than 0.01 in measured population',sum((d.P2-raw['∆PI_PEAK_Day_2']).abs()>0.01001))
res=pd.DataFrame(rows);print(res[res.term.isin(['published_high_PIMR','recorded_r1','r1','dE'])].round(5).to_string(index=False));res.to_csv(out/'source_peak_bridge.csv',index=False)

# Risk sets and missing second optical assessments, tabulated directly from the recorded follow-up day.
sets = {
    'all': np.ones(len(d), dtype=bool),
    'paired optical': d.B2.notna(),
    'paired CRT': d.dCRT.notna() & d.B2.notna(),
    'paired lactate': d.dloglac.notna() & d.B2.notna(),
    'follow-up through day 2': d.time_to_outcome.le(2),
    'follow-up through day 2 with paired optics': d.time_to_outcome.le(2) & d.B2.notna(),
    'follow-up through day 2 without day 2 optics': d.time_to_outcome.le(2) & d.B2.isna(),
    'follow-up after day 2': d.time_to_outcome.gt(2),
    'follow-up after day 2 with paired optics': d.time_to_outcome.gt(2) & d.B2.notna(),
    'follow-up after day 2 without day 2 optics': d.time_to_outcome.gt(2) & d.B2.isna(),
    'missing day 2 optics': d.B2.isna(),
    'missing day 2 optics with recorded day 9 death': d.B2.isna() & d.time_to_outcome.eq(9) & d.death.eq(1),
}
pd.DataFrame([{'risk_set': name, 'n': int(mask.sum()), 'deaths': int(d.loc[mask,'death'].sum())} for name,mask in sets.items()]).to_csv(out/'risk_sets.csv', index=False)
rs = lm[['E1','E2','dE','dx']].corr()
rs.to_csv(out/'landmark_correlations.csv')

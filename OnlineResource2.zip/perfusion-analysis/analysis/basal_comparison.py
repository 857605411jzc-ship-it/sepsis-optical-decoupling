"""Compare an optical challenge with the same model using basal perfusion alone."""
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
from landmark import SEED, CLINICAL, coordinates, fit_reference, probabilities
from published_load import load

HERE=Path(__file__).resolve().parents[1]
OUTPUT=HERE/'results'


def validate(q, target, models, contrasts, label):
    q=q.reset_index(drop=True).copy()
    q['death']=q[target].astype(int)
    y=q.death.to_numpy()
    n=len(q)
    preds={k:np.empty((n,20)) for k in models}
    for repeat in range(20):
        for train,test in StratifiedKFold(5,shuffle=True,random_state=SEED+repeat).split(q,y):
            tr=q.iloc[train];te=q.iloc[test]
            ref=fit_reference(tr)
            tr=coordinates(tr,ref);te=coordinates(te,ref)
            for name, features in models.items():
                preds[name][test,repeat]=probabilities(tr,te,features)
    counts=np.random.default_rng(SEED+227).multinomial(n,np.ones(n)/n,5000)
    pos=y==1
    norm=counts[:,pos].sum(1)*counts[:,~pos].sum(1)
    metrics=[];diffs=[];point={};boot={}
    for name,p in preds.items():
        errors=((p-y[:,None])**2).mean(1)
        c=p[pos,None,:]-p[None,~pos,:]
        concordance=((c>0)+.5*(c==0)).mean(2)
        auc=np.mean([roc_auc_score(y,p[:,r]) for r in range(20)])
        point[name]=np.array([errors.mean(),auc])
        boot[name]=np.stack([counts@errors/n,((counts[:,pos]@concordance)*counts[:,~pos]).sum(1)/norm])
        metrics.append(dict(task=label,model=name,n=n,events=int(y.sum()),Brier=errors.mean(),AUROC=auc))
    for nm,add in contrasts:
        d=point[add]-point[nm]
        ci=np.quantile(boot[add]-boot[nm],[.025,.975],axis=1)
        diffs.append(dict(task=label,base=nm,augmented=add,Brier_gain=-d[0],Brier_lo=-ci[1,0],Brier_hi=-ci[0,0],AUROC_gain=d[1],AUROC_lo=ci[0,1],AUROC_hi=ci[1,1]))
    return pd.DataFrame(metrics),pd.DataFrame(diffs)


def main():
    d=load(HERE/'data'/'cohort.sav')
    q=d[d.map_d1.ge(65)&d.crt_sec_d2.notna()].copy()
    q['target']=q.crt_sec_d2.gt(3).astype(int)
    macro=['age','map_d1']
    clinical=['age','sofa_d1','map_d1','crt_sec_d1','loglac1','vaso_d1']
    m,e=validate(q,'target',{'B1':['x1'],'B1_E1':['x1','E1'],'macro_B1':macro+['x1'],'macro_B1_E1':macro+['x1','E1'],'clinical1_B1':clinical+['x1'],'clinical1_B1_E1':clinical+['x1','E1']},[('B1','B1_E1'),('macro_B1','macro_B1_E1'),('clinical1_B1','clinical1_B1_E1')],'D2_CRT_gt3_among_D1_MAP_ge65')
    q=d[d.dx.notna()&d.time_to_outcome.gt(2)].copy()
    mm,ee=validate(q,'death',{'clinical2_B2':CLINICAL+['x2'],'clinical2_B2_E2':CLINICAL+['x2','E2'],'clinical2_dB':CLINICAL+['dx'],'clinical2_dB_dE':CLINICAL+['dx','dE']},[('clinical2_B2','clinical2_B2_E2'),('clinical2_dB','clinical2_dB_dE')],'post_D2_hospital_death')
    pd.concat([m,mm],ignore_index=True).to_csv(OUTPUT/'basal_metrics.csv',index=False)
    pd.concat([e,ee],ignore_index=True).to_csv(OUTPUT/'basal_contrasts.csv',index=False)


if __name__=='__main__':
    main()

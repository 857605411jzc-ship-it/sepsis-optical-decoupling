"""Recalculate the allometric reference and the originally archived trajectory bootstrap."""
import warnings
import numpy as np
import pandas as pd
from scipy import stats
from scipy.special import expit
from sklearn.linear_model import LogisticRegression
from pathlib import Path
from published_load import SEED, load


def ols(y, X, cluster=None):
    y, X = np.asarray(y, float), np.asarray(X, float)
    b = np.linalg.lstsq(X, y, rcond=None)[0]
    u = y - X @ b
    n, k = X.shape
    bread = np.linalg.pinv(X.T @ X)
    if cluster is None:
        h = np.sum((X @ bread) * X, axis=1)
        scores = X * (u / np.maximum(1 - h, 1e-8))[:, None]
        covariance = bread @ (scores.T @ scores) @ bread
        df = n - k
    else:
        groups = np.unique(cluster)
        scores = np.array([(X * u[:, None])[cluster == c].sum(axis=0) for c in groups])
        g = len(groups)
        covariance = bread @ (scores.T @ scores) @ bread * g / (g - 1) * (n - 1) / (n - k)
        df = g - 1
    se = np.sqrt(np.maximum(np.diag(covariance), 0))
    radius = stats.t.ppf(.975, df) * se
    return dict(beta=b, lo=b-radius, hi=b+radius, p=2*stats.t.sf(abs(b/se), df),
                se=se, df=df, r2=1-u@u/np.sum((y-y.mean())**2), cov=covariance)


def logit(y, X):
    y, X = np.asarray(y, float), np.asarray(X, float)
    mu, sd = X.mean(axis=0), X.std(axis=0)
    sd[sd == 0] = 1
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', FutureWarning)
        model = LogisticRegression(penalty=None, solver='lbfgs', max_iter=4000, tol=1e-10).fit((X-mu)/sd, y)
    if model.n_iter_[0] >= 4000:
        raise RuntimeError('Logistic fit did not converge')
    slopes = model.coef_[0] / sd
    b = np.r_[model.intercept_[0] - mu @ slopes, slopes]
    design = np.c_[np.ones(len(y)), X]
    p = expit(design @ b)
    covariance = np.linalg.pinv(design.T @ (design * (p*(1-p))[:, None]))
    se = np.sqrt(np.maximum(np.diag(covariance), 0))
    return dict(beta=b, lo=b-1.96*se, hi=b+1.96*se, p=2*stats.norm.sf(abs(b/se)), pred=p)



def analyze(d):
    rng, daily_rng = np.random.default_rng(SEED), np.random.default_rng(SEED+993)
    tables, estimates, intervals = {}, [], []
    for day in (1, 2):
        q = d.dropna(subset=[f'x{day}', f'y{day}'])
        x, y = q[f'x{day}'].to_numpy(), q[f'y{day}'].to_numpy()
        f = ols(y, np.c_[np.ones(len(q)), x])
        curved = ols(y, np.c_[np.ones(len(q)), x, (x-x.mean())**2])
        estimates.append(dict(day=day, n=len(q), alpha=f['beta'][0], alpha_lo=f['lo'][0], alpha_hi=f['hi'][0],
                              beta=f['beta'][1], lower95=f['lo'][1], upper95=f['hi'][1], r2=f['r2'],
                              p_beta_equals_one=2*stats.t.sf(abs((f['beta'][1]-1)/f['se'][1]), f['df']),
                              quadratic=curved['beta'][2], quadratic_p=curved['p'][2]))
        ix = daily_rng.integers(0, len(q), (5000, len(q)))
        xx, yy = x[ix], y[ix]
        xc, yc = xx-xx.mean(axis=1)[:, None], yy-yy.mean(axis=1)[:, None]
        slopes = (xc*yc).sum(axis=1)/(xc*xc).sum(axis=1)
        intercepts = yy.mean(axis=1)-slopes*xx.mean(axis=1)
        intervals.append(dict(day=day, bootstrap_lower95=np.quantile(slopes, .025), bootstrap_upper95=np.quantile(slopes, .975),
                              alpha_lower95=np.quantile(intercepts, .025), alpha_upper95=np.quantile(intercepts, .975)))
    a, b = estimates[0]['alpha'], estimates[0]['beta']
    for day in (1, 2):
        d[f'E{day}'] = d[f'y{day}']-a-b*d[f'x{day}']
    d['dE'] = d.E2-d.E1
    q = d.dropna(subset=['x1', 'x2', 'y1', 'y2'])
    delta = []
    for _ in range(5000):
        s = q.iloc[rng.integers(0, len(q), len(q))]
        delta.append(np.polyfit(s.x2, s.y2, 1)[0]-np.polyfit(s.x1, s.y1, 1)[0])
    stacked = pd.concat([pd.DataFrame({'id': d.patient_key, 'x': d[f'x{day}'], 'y': d[f'y{day}'], 'day2': day-1}) for day in (1, 2)]).dropna()
    f = ols(stacked.y, np.c_[np.ones(len(stacked)), stacked.x, stacked.day2, stacked.x*stacked.day2], stacked.id.to_numpy())
    paired_beta = [np.polyfit(q[f'x{day}'], q[f'y{day}'], 1)[0] for day in (1, 2)]
    tables['day_interaction'] = pd.DataFrame([dict(paired_n=len(q), paired_day1=paired_beta[0], paired_day2=paired_beta[1],
        difference=paired_beta[1]-paired_beta[0], bootstrap_lo=np.quantile(delta, .025), bootstrap_hi=np.quantile(delta, .975),
        stacked_n=len(stacked), cluster_n=stacked.id.nunique(), interaction=f['beta'][3], lo=f['lo'][3], hi=f['hi'][3], p=f['p'][3])])
    base = ['age', 'sofa_d1']
    features = base + ['x1', 'E1', 'dx', 'dE']
    for label, columns in [('mortality_BE', base+['x1', 'E1']), ('mortality_trajectory', features)]:
        draws = []
        for _ in range(1500):
            s = d.iloc[rng.integers(0, len(d), len(d))].copy()
            aa, bb = np.linalg.lstsq(np.c_[np.ones(len(s)), s.x1], s.y1, rcond=None)[0]
            s['E1'], s['E2'] = s.y1-aa-bb*s.x1, s.y2-aa-bb*s.x2
            s['dE'] = s.E2-s.E1
            if label == 'mortality_trajectory':
                s = s[s.time_to_outcome.gt(2)].dropna(subset=columns)
            draws.append(logit(s.death, s[columns])['beta'][-2:])
        limits = np.exp(np.quantile(draws, [.025, .975], axis=0))
        tables[label+'_refit_bootstrap'] = pd.DataFrame({'term': columns[-2:], 'OR_lower95': limits[0], 'OR_upper95': limits[1], 'replicates': 1500})
    tables['allometry'] = pd.DataFrame(estimates)
    tables['allometry_bootstrap'] = pd.DataFrame(intervals)
    return tables


if __name__ == '__main__':
    root = Path(__file__).resolve().parents[1]
    results = root / 'results' / 'sensitivity'
    results.mkdir(parents=True, exist_ok=True)
    cohort = load(root / 'data' / 'cohort.sav')
    for name, table in analyze(cohort).items():
        table.to_csv(results / f'{name}.csv', index=False)

"""Evaluate the locked resting-PI mortality model in the earlier Brazilian cohort."""
from hashlib import sha256
from pathlib import Path
from urllib.request import urlopen

import numpy as np
import pandas as pd
import pyreadstat
from scipy.special import expit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

from published_load import SEED, load


ROOT = Path(__file__).resolve().parents[1]
SOURCE = 'https://journals.plos.org/plosone/article/file?id=10.1371/journal.pone.0239770.s004&type=supplementary'
DIGEST = 'adbecca372e88386624c9bee844c2b1f07be017e9c58660ff99d14fd77168a59'


def load_external(path):
    if not path.exists():
        with urlopen(SOURCE, timeout=90) as response:
            content = response.read()
        if sha256(content).hexdigest() != DIGEST:
            raise ValueError('External source checksum differs')
        path.parent.mkdir(exist_ok=True, parents=True)
        path.write_bytes(content)
    if sha256(path.read_bytes()).hexdigest() != DIGEST:
        raise ValueError('External source checksum differs')
    raw, meta = pyreadstat.read_sav(path)
    if meta.variable_value_labels['Mortality'] != {0: 'Survivors', 1: 'Non-Survivors'}:
        raise ValueError('External outcome coding differs')
    return raw


def summarize(training, external):
    x = training.x1.to_numpy()
    center, scale = x.mean(), x.std()
    model = LogisticRegression(C=np.inf, solver='lbfgs', tol=1e-10, max_iter=4000)
    model.fit(((x - center) / scale).reshape(-1, 1), training.death)
    slope = model.coef_[0, 0] / scale
    intercept = model.intercept_[0] - slope * center

    # This column holds the continuous index; the similarly named field is binary.
    pi = external['Periperal_perfusion_index_24hours']
    observed = pi.gt(0) & external.Mortality.isin([0, 1])
    z = np.log2(pi.loc[observed].to_numpy())
    outcome = external.loc[observed, 'Mortality'].astype(int).to_numpy()
    risk = expit(intercept + slope * z)
    n = len(outcome)
    counts = np.random.default_rng(SEED + 908).multinomial(n, np.full(n, 1 / n), size=5000)
    events = outcome == 1
    concordance = (risk[events, None] > risk[None, ~events]).astype(float)
    concordance += 0.5 * (risk[events, None] == risk[None, ~events])
    event_n = counts[:, events].sum(axis=1)
    control_n = n - event_n
    valid = (event_n > 0) & (control_n > 0)
    ordered = ((counts[valid][:, events] @ concordance) * counts[valid][:, ~events]).sum(axis=1)
    aucs = ordered / (event_n[valid] * control_n[valid])
    lower, upper = np.quantile(aucs, [0.025, 0.975])
    return pd.DataFrame([{
        'derivation_n': len(training), 'derivation_deaths': int(training.death.sum()),
        'intercept': intercept, 'coefficient_log2_PI': slope,
        'validation_n_total': len(external), 'validation_n': n,
        'deaths': int(outcome.sum()), 'observed_proportion': outcome.mean(),
        'mean_predicted_proportion': risk.mean(), 'AUROC': roc_auc_score(outcome, risk),
        'AUROC_lo': lower, 'AUROC_hi': upper, 'Brier': np.mean((outcome - risk) ** 2),
        'resamples': len(aucs)
    }])


def main():
    training = load(ROOT / 'data' / 'cohort.sav')
    external = load_external(ROOT / 'data' / 'resting_2019.sav')
    target = ROOT / 'results' / 'external'
    target.mkdir(exist_ok=True, parents=True)
    summarize(training, external).to_csv(target / 'basal_mortality.csv', index=False)


if __name__ == '__main__':
    main()

"""Assess nonlinear peak information in the same patient-held-out folds."""
import argparse
from pathlib import Path
import sys

import pandas as pd


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True,
                        help="Directory containing analysis/ and data/")
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    sys.path.insert(0, str(args.base.resolve() / "analysis"))
    from published_load import load
    from basal_comparison import validate

    cohort = load(args.base / "data" / "cohort.sav")
    # x and y are log2 basal and peak PI. The full quadratic spans the same
    # predictors as x, E, x**2, x*E and E**2 for every training reference.
    cohort["basal_sq"] = cohort.x1 ** 2
    cohort["peak_sq"] = cohort.y1 ** 2
    cohort["basal_peak"] = cohort.x1 * cohort.y1
    basal = ["x1", "basal_sq"]
    models = {"quadratic_basal": basal,
              "quadratic_basal_peak": basal + ["y1", "peak_sq", "basal_peak"]}
    contrast = [("quadratic_basal", "quadratic_basal_peak")]
    normal_map = cohort.loc[cohort.map_d1.ge(65) & cohort.crt_sec_d2.notna()].copy()
    normal_map["crt_prolonged"] = normal_map.crt_sec_d2.gt(3).astype(int)
    tasks = [(normal_map, "crt_prolonged", "day2_CRT_gt3", 211, 66),
             (cohort, "death", "day28_in_hospital_death", 226, 90)]
    rows = []
    for frame, target, endpoint, n, events in tasks:
        assert len(frame) == n and int(frame[target].sum()) == events
        metrics, contrasts = validate(frame, target, models, contrast, endpoint)
        estimates = metrics.set_index("model")
        row = dict(endpoint=endpoint, n=n, events=events)
        for score in ("AUROC", "Brier"):
            row[f"B_{score}"] = estimates.at["quadratic_basal", score]
            row[f"B_P_{score}"] = estimates.at["quadratic_basal_peak", score]
            for term in ("gain", "lo", "hi"):
                row[f"{score}_{term}"] = contrasts.at[0, f"{score}_{term}"]
        rows.append(row)
    args.out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(args.out / "peak_interaction.csv", index=False)


if __name__ == "__main__":
    main()

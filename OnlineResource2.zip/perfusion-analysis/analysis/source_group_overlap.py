"""Describe basal perfusion by recorded source group and paired coefficient change."""
import argparse
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import pyreadstat

from refit_validation import fit_logistic


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--resamples", type=int, default=2000)
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent / "results")
    args = parser.parse_args()
    sys.path.insert(0, str(args.base.resolve() / "analysis"))
    from published_load import load, SEED

    path = args.base / "data" / "cohort.sav"
    cohort = load(path)
    raw, _ = pyreadstat.read_sav(path)
    cohort["group"] = raw["∆PI_PEAK_D1_A"]
    cohort["heart_rate"] = raw["Heart_Rate_Day1"]
    covariates = ["age", "sofa_d1", "heart_rate", "lactate1"]
    data = cohort.dropna(subset=["death", "group", "x1"] + covariates).copy()
    summaries = []
    for group, patients in data.groupby("group"):
        for field in ["B1", "P1", "R1", "crt_sec_d1"]:
            values = patients[field].dropna()
            q1, median, q3 = values.quantile([.25, .5, .75])
            summaries.append(dict(group=int(group), variable=field, n=len(values),
                                  median=median, q1=q1, q3=q3,
                                  deaths=int(patients.death.sum())))
    rng = np.random.default_rng(SEED + 271828)
    n = len(data)
    counts = np.vstack((np.ones(n), rng.multinomial(n, np.full(n, 1/n), args.resamples)))
    group = data.group.to_numpy()
    variables = data[covariates + ["x1"]]
    standardized = (variables - variables.mean()) / variables.std(ddof=0)
    matrix = np.column_stack((np.ones(n), group, standardized))
    source, adjusted = [], []
    for start in range(0, len(counts), 96):
        w = counts[start:start+96]
        source.extend(fit_logistic(matrix[:, :-1], data.death.to_numpy(), w)[:, 1])
        adjusted.extend(fit_logistic(matrix, data.death.to_numpy(), w)[:, 1])
    source, adjusted = np.asarray(source), np.asarray(adjusted)
    params = {"source_OR": np.exp(source), "basal_adjusted_OR": np.exp(adjusted),
              "adjusted_OR_over_source_OR": np.exp(adjusted - source)}
    rows = []
    for name, draws in params.items():
        lo, med, hi = np.quantile(draws[1:], [.025, .5, .975])
        rows.append(dict(parameter=name, n=n, deaths=int(data.death.sum()),
                         bootstrap=args.resamples, estimate=draws[0],
                         lower95=lo, bootstrap_median=med, upper95=hi))
    args.out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(summaries).to_csv(args.out / "source_group_distributions.csv", index=False)
    pd.DataFrame(rows).to_csv(args.out / "source_OR_paired_refit.csv", index=False)


if __name__ == "__main__":
    main()

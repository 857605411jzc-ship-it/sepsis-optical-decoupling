from pathlib import Path
import warnings

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
from scipy.stats import norm

from published_load import SEED, load

HERE = Path(__file__).resolve().parents[1]
OUTPUT = HERE/'results'
CLINICAL = ['age', 'sofa2', 'map_d2', 'crt_sec_d2', 'loglac2', 'vp2']
OPTICAL = {
    'clinical': [], 'clinical_change': ['dx', 'dE'],
    'clinical_day1': ['x1', 'E1'], 'clinical_day2': ['x2', 'E2'],
    'clinical_both_change': ['x1', 'E1', 'dx', 'dE'],
    'clinical_both_raw': ['x1', 'y1', 'x2', 'y2']
}
PAIRED = [('clinical', 'clinical_change'), ('clinical_day1', 'clinical_both_change'),
          ('clinical_day2', 'clinical_both_change'), ('clinical', 'clinical_day2'),
          ('clinical', 'clinical_both_change')]


def fit_reference(frame):
    design = np.column_stack([np.ones(len(frame)), frame.x1])
    return np.linalg.lstsq(design, frame.y1, rcond=None)[0]


def coordinates(frame, ref):
    frame = frame.copy()
    alpha, beta = ref
    for day in [1, 2]:
        frame[f'E{day}'] = frame[f'y{day}'] - alpha - beta * frame[f'x{day}']
    frame['dE'] = frame.E2 - frame.E1
    return frame


def probabilities(train, test, features):
    medians = train[features].median()
    x = train[features].fillna(medians).to_numpy()
    z = test[features].fillna(medians).to_numpy()
    mean = x.mean(axis=0)
    scale = x.std(axis=0)
    scale[scale == 0] = 1
    model = LogisticRegression(C=np.inf, solver='lbfgs', tol=1e-10, max_iter=4000)
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', message='Setting penalty=None will ignore the C and l1_ratio parameters', category=UserWarning)
        model.fit((x-mean)/scale, train.death)
    assert model.n_iter_[0] < 4000
    return model.predict_proba((z-mean)/scale)[:, 1]


def evaluate(q, predictors, label):
    n = len(q)
    outcome = q.death.to_numpy(int)
    pred = {name: np.empty((n, 20)) for name in OPTICAL}
    for repeat in range(20):
        splitter = StratifiedKFold(5, shuffle=True, random_state=SEED+repeat)
        for train, test in splitter.split(q, outcome):
            ref = fit_reference(q.iloc[train])
            tr = coordinates(q.iloc[train], ref)
            te = coordinates(q.iloc[test], ref)
            for name, optical in OPTICAL.items():
                pred[name][test, repeat] = probabilities(tr, te, predictors+optical)
    print(label, 'max OOF probability discrepancy across equivalent coordinates',
          np.abs(pred['clinical_both_raw']-pred['clinical_both_change']).max())
    rng = np.random.default_rng(SEED+227)
    counts = rng.multinomial(n, np.ones(n)/n, size=5000)
    positives = outcome == 1
    denominator = counts[:, positives].sum(1)*counts[:, ~positives].sum(1)
    metrics, estimates, distributions = [], {}, {}
    for name, values in pred.items():
        meanloss = ((values-outcome[:, None])**2).mean(axis=1)
        scores = values[positives, None, :] - values[None, ~positives, :]
        concordance = ((scores > 0) + 0.5*(scores == 0)).mean(axis=2)
        auc = np.mean([roc_auc_score(outcome, values[:, i]) for i in range(20)])
        p = np.clip(values, 1e-15, 1-1e-15)
        ll = -(np.log(p)*outcome[:, None] + np.log1p(-p)*(1-outcome[:, None])).mean()
        estimates[name] = np.array([meanloss.mean(), auc])
        brier_b = counts @ meanloss / n
        auc_b = ((counts[:, positives] @ concordance)*counts[:, ~positives]).sum(1)/denominator
        distributions[name] = np.stack([brier_b, auc_b])
        metrics.append(dict(analysis=label, model=name, n=n, events=int(outcome.sum()),
                            Brier=meanloss.mean(), AUROC=auc, logloss=ll))
    effects = []
    for base, augmented in PAIRED:
        difference = estimates[augmented]-estimates[base]
        distribution = distributions[augmented]-distributions[base]
        ci = np.quantile(distribution, [.025, .975], axis=1)
        effects.append(dict(analysis=label, base=base, augmented=augmented,
                            Brier_gain=-difference[0], Brier_gain_lower=-ci[1, 0],
                            Brier_gain_upper=-ci[0, 0], AUROC_gain=difference[1],
                            AUROC_gain_lower=ci[0, 1], AUROC_gain_upper=ci[1, 1]))
    return pd.DataFrame(metrics), pd.DataFrame(effects)


def wilson(k, n):
    z = norm.ppf(.975)
    p = k/n
    centre = (p+z*z/(2*n))/(1+z*z/n)
    half = z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
    return centre-half, centre+half


def main():
    d = load(HERE/'data'/'cohort.sav')
    q = d[d.dx.notna() & d.time_to_outcome.gt(2)].reset_index(drop=True)
    assert len(q) == 208 and q.death.sum() == 73
    q['NE_dose_recorded'] = q.norepi2.notna().astype(float)
    q['lactate_recorded'] = q.loglac2.notna().astype(float)
    configurations = [
        (q, CLINICAL, 'primary'), (q, CLINICAL+['norepi2', 'NE_dose_recorded', 'lactate_recorded'], 'recording_sensitivity'),
        (q.dropna(subset=CLINICAL).reset_index(drop=True), CLINICAL, 'complete_clinical')
    ]
    metrics, effects = [], []
    for sample, features, label in configurations:
        m, e = evaluate(sample, features, label)
        metrics.append(m)
        effects.append(e)
    pd.concat(metrics, ignore_index=True).to_csv(OUTPUT/'metrics.csv', index=False)
    pd.concat(effects, ignore_index=True).to_csv(OUTPUT/'contrasts.csv', index=False)
    q = coordinates(q, fit_reference(d))
    rows = []
    for name, sample in [('D2_CRT_le3', q[q.crt_sec_d2.le(3)]),
                         ('D1_gt3_D2_le3', q[q.crt_sec_d1.gt(3) & q.crt_sec_d2.le(3)])]:
        for category, subgroup in sample.groupby(q.dE.lt(0)):
            n = len(subgroup)
            k = int(subgroup.death.sum())
            low, high = wilson(k, n)
            rows.append(dict(subgroup=name, dE='negative' if category else 'nonnegative',
                             n=n, deaths=k, risk=k/n, lower=low, upper=high))
    pd.DataFrame(rows).to_csv(OUTPUT/'crt_subgroups.csv', index=False)


if __name__ == '__main__':
    main()

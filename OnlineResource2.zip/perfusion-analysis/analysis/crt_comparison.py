"""Compare baseline CRT and optical measurements with identical validation splits."""

import argparse
from pathlib import Path
import sys

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ANALYSIS = ROOT
MODELS = {
    "B": ["x1"],
    "B_E": ["x1", "E1"],
    "CRT": ["crt_sec_d1"],
    "CRT_B": ["crt_sec_d1", "x1"],
    "CRT_B_E": ["crt_sec_d1", "x1", "E1"],
    "R": ["r1"],
}
CONTRASTS = [
    ("B", "B_E"),
    ("CRT", "B"),
    ("CRT", "CRT_B"),
    ("CRT_B", "CRT_B_E"),
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=DEFAULT_ANALYSIS,
                        help="Directory containing analysis/ and data/")
    args = parser.parse_args()
    base = args.base.resolve()
    if not (base / "analysis" / "basal_comparison.py").is_file():
        parser.error("Missing analysis/basal_comparison.py in the specified directory.")
    sys.path.insert(0, str(base / "analysis"))
    from basal_comparison import validate
    from published_load import load

    data = load(base / "data" / "cohort.sav")
    map_eligible = data.loc[data.map_d1.ge(65)]
    missing = map_eligible.loc[map_eligible.crt_sec_d2.isna()]
    sample = map_eligible.loc[map_eligible.crt_sec_d2.notna()].copy()
    flow = {
        "source_cohort": len(data),
        "map_eligible": len(map_eligible),
        "nextday_crt_observed": len(sample),
        "nextday_crt_missing": len(missing),
        "deaths_among_missing_nextday_crt": int(missing.death.sum()),
        "deaths_by_day2_among_missing_nextday_crt": int(
            (missing.death.eq(1) & missing.time_to_outcome.le(2)).sum()
        ),
        "missing_day1_crt_in_analysis": int(sample.crt_sec_d1.isna().sum()),
        "day2_crt_equal_to_3_seconds": int(sample.crt_sec_d2.eq(3).sum()),
    }
    assert len(sample) == 211 and sample.crt_sec_d2.gt(3).sum() == 66
    results = ROOT / "results" / "comparisons"
    results.mkdir(parents=True, exist_ok=True)
    pd.Series(flow, name="count").rename_axis("population").to_csv(results / "denominators.csv")
    outcomes = {
        "day2_CRT_gt3": sample.crt_sec_d2.gt(3),
        "day2_CRT_ge3": sample.crt_sec_d2.ge(3),
    }
    metrics, contrasts = [], []
    for label, outcome in outcomes.items():
        sample["target"] = outcome.astype(int)
        estimates, differences = validate(sample, "target", MODELS, CONTRASTS, label)
        metrics.append(estimates)
        contrasts.append(differences)
    optical_models = {k: MODELS[k] for k in ("B", "B_E", "R")}
    assert len(data) == 226 and data.death.sum() == 90
    estimates, differences = validate(
        data, "death", optical_models, [("B", "B_E"), ("R", "B_E")],
        "day28_in_hospital_death",
    )
    metrics.append(estimates)
    contrasts.append(differences)
    pd.concat(metrics, ignore_index=True).to_csv(results / "metrics.csv", index=False)
    pd.concat(contrasts, ignore_index=True).to_csv(results / "paired_contrasts.csv", index=False)


if __name__ == "__main__":
    main()


"""Refit the optical models in participant resamples and score held-out patients."""
import argparse
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.model_selection import StratifiedKFold


def fit_logistic(design, outcome, counts):
    """Solve independent unpenalized likelihoods with frequency weights."""
    design = np.ascontiguousarray(design)
    products = (design[:, :, None] * design[:, None, :]).reshape(len(design), -1)
    coef = np.zeros((len(counts), design.shape[1]))
    for _ in range(40):
        fitted = expit(coef @ design.T)
        score = (counts * (outcome - fitted)) @ design
        if np.max(np.abs(score)) < 1e-8:
            return coef
        variance = counts * fitted * (1 - fitted)
        information = (variance @ products).reshape(-1, design.shape[1], design.shape[1])
        coef += np.linalg.solve(information, score[:, :, None])[:, :, 0]
    raise RuntimeError("At least one weighted likelihood failed to converge.")


def holdout_predictions(x, y, event, train, test, counts):
    basis = np.column_stack((np.ones(len(x)), x, y))
    w = np.ascontiguousarray(counts[:, train])
    X = basis[train]
    basal = fit_logistic(X[:, :2], event[train], w)
    joint = fit_logistic(X, event[train], w)
    # The log-peak basis and each resample's residual basis span the same model.
    # Convert the fitted coefficients to the residual basis for the held-out data.
    weights = w / w.sum(axis=1, keepdims=True)
    xt, yt = x[train], y[train]
    mx, my = weights @ xt, weights @ yt
    beta = ((weights @ (xt * yt)) - mx * my) / ((weights @ (xt * xt)) - mx * mx)
    alpha = my - beta * mx
    adjusted = y[test] - alpha[:, None] - beta[:, None] * x[test]
    conditional = ((joint[:, 0] + joint[:, 2] * alpha)[:, None]
                   + (joint[:, 1] + joint[:, 2] * beta)[:, None] * x[test]
                   + joint[:, 2, None] * adjusted)
    np.testing.assert_allclose(conditional, joint @ basis[test].T, atol=5e-13)
    return expit(basal @ basis[test, :2].T), expit(conditional)


def get_scores(event, prediction, counts):
    # All predictions in a repeat come from a fold where the patient was held out.
    case, control = event == 1, event == 0
    diffs = prediction[:, case, None] - prediction[:, None, control]
    concordant = (diffs > 0).astype(float) + 0.5 * (diffs == 0)
    n_case = counts[:, case].sum(axis=1)
    n_control = counts[:, control].sum(axis=1)
    auc = np.einsum("bi,bij,bj->b", counts[:, case], concordant, counts[:, control])
    auc /= n_case * n_control
    brier = np.sum(counts * (prediction - event) ** 2, axis=1) / counts.sum(axis=1)
    return auc, brier


def bootstrap_validation(frame, event, seed, n_resamples, repeats=20):
    x, y = frame.x1.to_numpy(), frame.y1.to_numpy()
    event = np.asarray(event, dtype=int)
    n = len(event)
    rng = np.random.default_rng(seed + 314159)
    counts = np.vstack((np.ones(n), rng.multinomial(n, np.full(n, 1 / n), n_resamples)))
    # Duplicates follow the original patient's fold in every replicate.
    splits = [list(StratifiedKFold(5, shuffle=True, random_state=seed + i)
                   .split(x, event)) for i in range(repeats)]
    outputs = []
    for start in range(0, len(counts), 96):
        weights = counts[start:start + 96]
        result = np.zeros((len(weights), 4))
        for repeat in splits:
            basal = np.empty(weights.shape)
            joint = np.empty_like(basal)
            for train, test in repeat:
                basal[:, test], joint[:, test] = holdout_predictions(
                    x, y, event, train, test, weights)
            auc_b, brier_b = get_scores(event, basal, weights)
            auc_e, brier_e = get_scores(event, joint, weights)
            result += np.column_stack((auc_b, auc_e, brier_b, brier_e))
        outputs.append(result / repeats)
    return np.vstack(outputs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True,
                        help="Directory containing analysis/ and data/")
    parser.add_argument("--resamples", type=int, default=2000)
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent / "results")
    args = parser.parse_args()
    sys.path.insert(0, str(args.base.resolve() / "analysis"))
    from published_load import SEED, load
    data = load(args.base / "data" / "cohort.sav")
    crt = data.loc[data.map_d1.ge(65) & data.crt_sec_d2.notna()].copy()
    tasks = {"day2_CRT_gt3": (crt, crt.crt_sec_d2.gt(3)),
             "day2_CRT_ge3": (crt, crt.crt_sec_d2.ge(3)),
             "day28_in_hospital_death": (data, data.death)}
    rows = []
    for name, (frame, event) in tasks.items():
        result = bootstrap_validation(frame, event, SEED, args.resamples)
        metrics = {"B_AUROC": result[:, 0], "B_E_AUROC": result[:, 1],
                   "B_Brier": result[:, 2], "B_E_Brier": result[:, 3],
                   "AUROC_gain": result[:, 1] - result[:, 0],
                   "Brier_gain": result[:, 2] - result[:, 3]}
        for label, values in metrics.items():
            low, median, high = np.quantile(values[1:], [.025, .5, .975])
            rows.append(dict(endpoint=name, n=len(frame), events=int(event.sum()),
                             replicates=args.resamples, metric=label, estimate=values[0],
                             lower=low, bootstrap_median=median, upper=high))
    args.out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(args.out / "refitted_validation.csv", index=False)


if __name__ == "__main__":
    main()

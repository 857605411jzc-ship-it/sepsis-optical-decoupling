"""Reconstruct the published Day 1 high-PIMR model from the original S1 indicators."""
from pathlib import Path
import numpy as np
import pandas as pd
import pyreadstat
from scipy.special import expit
from scipy.stats import norm
from scipy.optimize import minimize
from published_load import load

HERE=Path(__file__).resolve().parents[1]
OUTPUT=HERE/'results'


def logistic(frame, columns):
    x=frame[columns].to_numpy(dtype=float)
    y=frame.death.to_numpy(dtype=float)
    design=np.column_stack([np.ones(len(y)),(x-x.mean(axis=0))/x.std(axis=0)])
    def nll(b):
        lp=design@b
        return (np.logaddexp(0,lp)-y*lp).sum(),design.T@(expit(lp)-y)
    fit=minimize(nll,np.zeros(design.shape[1]),jac=True,method='BFGS',tol=1e-9)
    beta=fit.x
    p=expit(design@beta)
    score=design.T@(p-y)
    assert abs(score).max()<1e-5
    info=design.T@(design*(p*(1-p))[:,None])
    se=np.sqrt(np.diag(np.linalg.inv(info)))[1:]/x.std(axis=0)
    b=beta[1:]/x.std(axis=0)
    return pd.DataFrame({'term':columns,'OR':np.exp(b),'lower95':np.exp(b-1.96*se),
                         'upper95':np.exp(b+1.96*se),'p':2*norm.sf(abs(b/se))})


def main():
    d=load(HERE/'data'/'cohort.sav')
    raw,_=pyreadstat.read_sav(HERE/'data'/'cohort.sav')
    d['high_PIMR_recorded']=raw['∆PI_PEAK_D1_A']
    d['heart_rate_day1']=raw['Heart_Rate_Day1']
    d['high_PIMR_ge62_from_percent']=(raw['∆PI_PEAK_D1']>=62).astype(int)
    d['high_PIMR_gt62_from_percent']=(raw['∆PI_PEAK_D1']>62).astype(int)
    d['high_PIMR_ge62_from_samples']=(d.R1>=1.62).astype(int)
    fields=['age','sofa_d1','heart_rate_day1','lactate1']
    rows=[]; groups=[]
    for k in ['high_PIMR_recorded','high_PIMR_ge62_from_percent','high_PIMR_gt62_from_percent','high_PIMR_ge62_from_samples']:
        groups.append(dict(encoding=k,total_high=int(d[k].sum()),flag_mismatches=int(d[k].ne(d.high_PIMR_recorded).sum())))
        q=d.dropna(subset=['death',k]+fields+['x1'])
        for spec,cols in [('source_covariates',fields+[k]),('add_log2_basal_PI',fields+[k,'x1'])]:
            out=logistic(q,cols)
            out.insert(0,'deaths',int(q.death.sum()));out.insert(0,'n',len(q))
            out.insert(0,'model',spec);out.insert(0,'encoding',k)
            rows.append(out)
    pd.concat(rows,ignore_index=True).to_csv(OUTPUT/'source_table2_results.csv',index=False)
    pd.DataFrame(groups).to_csv(OUTPUT/'source_table2_encoding.csv',index=False)


if __name__=='__main__':
    main()
